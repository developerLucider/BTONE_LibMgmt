INSERT INTO edu.books_age_check (goods_id,goods_age_limit) VALUES
	 ('A1','y'),
	 ('A2','y'),
	 ('A3','n'),
	 ('A4','y'),
	 ('A5','n'),
	 ('B1','n'),
	 ('b2','y'),
	 ('b3','y'),
	 ('C1','y'),
	 ('C2','n');
INSERT INTO edu.books_age_check (goods_id,goods_age_limit) VALUES
	 ('C3','n'),
	 ('C4','n'),
	 ('C5','n'),
	 ('','y'),
	 ('A7','n');
