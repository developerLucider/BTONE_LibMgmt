INSERT INTO edu.user_age_check (user_no,user_age_check_yn) VALUES
	 (2,'n'),
	 (3,'y'),
	 (4,'n'),
	 (5,'n'),
	 (6,'n'),
	 (7,'n'),
	 (8,'n'),
	 (9,'n'),
	 (10,'y'),
	 (11,'n');
INSERT INTO edu.user_age_check (user_no,user_age_check_yn) VALUES
	 (12,'n'),
	 (13,'n'),
	 (14,'n'),
	 (15,'n'),
	 (16,'n'),
	 (17,'n'),
	 (18,'n'),
	 (19,'n'),
	 (20,'n'),
	 (33,'n');
INSERT INTO edu.user_age_check (user_no,user_age_check_yn) VALUES
	 (35,'n'),
	 (38,'n'),
	 (39,'n'),
	 (40,'y'),
	 (41,'n');
