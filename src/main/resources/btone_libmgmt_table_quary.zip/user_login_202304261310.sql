INSERT INTO edu.user_login (user_no,user_name,user_id,user_password,user_address,user_reg_no) VALUES
	 (1,'김영진','testIds','1234','',''),
	 (2,'김영진','testIds1','1234','',''),
	 (3,'김민석','kms','MTIzcXdlIQ==',NULL,'9409031234567'),
	 (4,'모현진','text1','YWFhYTEyMzQh','',''),
	 (5,'모현진','test2','YWFhYTEyMzQh','',''),
	 (6,'천소진','sojin91','YXNkZjEyMyQ=','서울',''),
	 (7,'박상훈','tkdgns0056','park0056',NULL,''),
	 (8,'짜무니','park0056','cGFyazAwNTYwMCE=','성남시',''),
	 (9,'박상훈','test1234','cGFyazAwNTYwMCE=','비티원',''),
	 (10,'신승현','tmdgus3173','IUAhQHRsc3RtZDEy','서울 관악구 행운길 50 201호','9512141323411');
INSERT INTO edu.user_login (user_no,user_name,user_id,user_password,user_address,user_reg_no) VALUES
	 (11,'모현진','text4','YWFhYTEyMzQh','','0409231234567'),
	 (12,'모현진','text5','YWFhYTEyMzQh','',''),
	 (13,'모현진','text7','YWFhYTEyMzQh','',''),
	 (14,'모현진','text8','1234','',''),
	 (15,'천소진','sojin','Y2pzdGh3bHM3NCE=','서울 동작구 국사봉1길 123-3401호','9107042100000'),
	 (16,'모현진','text12','YWFhYTEyMzQh','서울 성동구 연무장5가길 712077','970923123457'),
	 (17,'모현진','text14','YWFhYTEyMzQh','경기 시흥시 현대마을길 111207','12345789102'),
	 (18,'모현진','text11','YWFhYTEyMzQh','서울 성동구 서울숲길 171207','123456789'),
	 (19,'모현진','text15','YWFhYTEyMzQh','서울 성동구 서울숲길 1811','123456789'),
	 (20,'모현진','text16','YWFhYTEyMzQh','부산 영도구 해돋이1길 1120','123456789');
INSERT INTO edu.user_login (user_no,user_name,user_id,user_password,user_address,user_reg_no) VALUES
	 (21,'모현진','text10','YWFhYTEyMzQh','경기 화성시 남양읍 현대기아로 831207','123456789'),
	 (22,'모현진','test4','YWFhYTEyMzQh','서울 성동구 고산자로 121207','9709231234567'),
	 (23,'모현진','test10','YWFhYTEyMzQh','서울 성동구 서울숲길 18111','9709231234567'),
	 (24,'모현진','test3','YWFhYTEyMzQh','경기 시흥시 현대마을길 191207','9709235678910'),
	 (25,'모현진','text18','YWFhYTEyMzQh','서울 영등포구 국회대로 494494','9709235555555'),
	 (26,'모','text17','YWFhYTEyMzQh','','9999999999999'),
	 (27,'모현진','test5','YWFhYTEyMzQh','인천 연수구 인천타워대로 지하 5711','9709236666666'),
	 (28,'모현진','test6','YWFhYTEyMzQh','부산 영도구 향촌길 3411','9709238888888'),
	 (29,'모현진','text22','YWFhYTEyMzQh','','9709231111111'),
	 (30,'모현진','test7','YWFhYTEyMzQh','','9709231111111');
INSERT INTO edu.user_login (user_no,user_name,user_id,user_password,user_address,user_reg_no) VALUES
	 (31,'모현진','test8','YWFhYTEyMzQh','','9709255555555'),
	 (32,'모현진','test9','YWFhYTEyMzQh','','9709234444444'),
	 (33,'모현진','text23','YWFhYTEyMzQh','','9709232222222'),
	 (34,'모현진','test24','YWFhYTEyMzQh','','9709232222222'),
	 (35,'모현진','test25','YWFhYTEyMzQh','','9709231111111'),
	 (36,'김민석','mstest','MXEh','서울 성동구 가람길 110E동 1207호','1234561234567'),
	 (38,'모','text6','YWFhYTEyMzQh','서울 성동구 연무장5가길 71207','0409231234567'),
	 (39,'모현진','test08','aaaa1234!','서울 성동구 연무장5가길 71207','0409231234567'),
	 (40,'테스트유저','userAutoId','IUAhQHRsc3RtZDEy','','9508221170510'),
	 (41,'테스어드민','adminAutoId','IUAhQHRsc3RtZDEy','','1111111111111');
