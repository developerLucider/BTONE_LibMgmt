INSERT INTO edu.books (goods_id,goods_name,goods_price) VALUES
	 ('','',''),
	 ('A1','JAVA_BOOK ','20000'),
	 ('A2','JAVA_BOOKS','3500'),
	 ('A3','JAVA의 정석 활용','10000'),
	 ('A4','JAVA의 정석','25000'),
	 ('A5','JAVA의 정석 활용','30000'),
	 ('A7','java','3000'),
	 ('B1','MYSQL_BOOK','30000'),
	 ('b2','NEW_BOOK','20000'),
	 ('b3','SPING_MASTER','23400');
INSERT INTO edu.books (goods_id,goods_name,goods_price) VALUES
	 ('C1','JSP_BOOK','15000'),
	 ('C2','ECLIPSE_BOOK','15000'),
	 ('C3','ECLIPSE 활용하기','30000'),
	 ('C4','자바란 무엇인가?','20000'),
	 ('C5','인텔리제이 알아보기','10000');
