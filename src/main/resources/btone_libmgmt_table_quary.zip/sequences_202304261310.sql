INSERT INTO edu.sequences (name,currval) VALUES
	 ('next_seq',41),
	 ('next_seq',41);
