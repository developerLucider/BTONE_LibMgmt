INSERT INTO edu.book_popular_word (book_popw_word) VALUES
	 ('JAVA의 정석'),
	 ('JAVA의 정석 활용'),
	 ('JAVA의 정석 활용'),
	 ('JAVA의 정석'),
	 ('JAVA의 정석'),
	 ('JAVA'),
	 ('스프링'),
	 ('java의 정석'),
	 ('JAVA의 정석 활용'),
	 ('ECLIPSE 활용하기');
INSERT INTO edu.book_popular_word (book_popw_word) VALUES
	 ('JSP_BOOK'),
	 ('java'),
	 ('java'),
	 ('java'),
	 ('JSP_BOOK'),
	 ('JAVA의 정석 활용'),
	 ('랭킹1'),
	 ('스프링'),
	 ('JAVA의 정석 활용'),
	 ('JAVA의 정석 활용');
INSERT INTO edu.book_popular_word (book_popw_word) VALUES
	 ('JSP_BOOK'),
	 ('ECLIPSE 활용하기'),
	 ('mysql'),
	 ('mysql'),
	 ('mysql'),
	 ('mysql'),
	 ('mysql'),
	 ('MYSQL_BOOK'),
	 ('JAVA의 정석 활용'),
	 ('ECLIPSE 활용하기');
INSERT INTO edu.book_popular_word (book_popw_word) VALUES
	 ('JAVA의 정석 활용'),
	 ('JAVA의 정석 활용'),
	 ('ECLIPSE 활용하기'),
	 ('JAVA의 정석 활용'),
	 ('JAVA의 정석 활용'),
	 ('ECLIPSE 활용하기'),
	 ('JAVA의 정석 활용'),
	 ('JAVA의 정석 활용'),
	 ('JAVA_BOOKS');
