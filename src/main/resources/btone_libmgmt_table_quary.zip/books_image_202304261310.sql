INSERT INTO edu.books_image (goods_id,image_original_name,image_saved_name,image_path) VALUES
	 ('A1','sunset-1373171__340.jpg','ce443922-4bf0-4365-aa7a-6f76dde403b3_sunset-1373171__340.jpg','C:\\DEV\\workspace\\BTONE_LibMgmt\\src\\main\\resources\\static\\img\\'),
	 ('A2','palm-2445107__340.png','c83e060f-cc33-4e82-9365-468fbdb44346_palm-2445107__340.png','C:\\DEV\\workspace\\BTONE_LibMgmt\\src\\main\\resources\\static\\img\\'),
	 ('A3','swan-1868697__340.png','372b0d25-1111-4866-a319-fcff4923345e_swan-1868697__340.png','C:\\DEV\\workspace\\BTONE_LibMgmt\\src\\main\\resources\\static\\img\\');
