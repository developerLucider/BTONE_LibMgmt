INSERT INTO edu.books_count (goods_id,goods_quantity) VALUES
	 ('A1',10),
	 ('A2',10),
	 ('A3',2),
	 ('A4',1),
	 ('A5',2),
	 ('B1',3),
	 ('b2',5),
	 ('b3',5),
	 ('C1',10),
	 ('C2',1);
INSERT INTO edu.books_count (goods_id,goods_quantity) VALUES
	 ('C3',0),
	 ('C5',10),
	 ('C4',5),
	 ('',0),
	 ('A7',3);
