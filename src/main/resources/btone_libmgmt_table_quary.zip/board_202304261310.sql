INSERT INTO edu.board (boardTitle,boardContent,boardName,boardCreateTime,boardUpdateTime) VALUES
	 ('테스트1','내용 테스트1','작성자1','지금','지금');
