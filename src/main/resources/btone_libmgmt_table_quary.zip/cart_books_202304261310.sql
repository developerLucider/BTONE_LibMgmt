INSERT INTO edu.cart_books (user_no,goods_id) VALUES
	 ('21','A1'),
	 ('21','A3'),
	 ('21','A4');
