INSERT INTO edu.books_event_info (goods_id,event_id) VALUES
	 ('A1','A'),
	 ('A4','C'),
	 ('B1','B'),
	 ('A3','A'),
	 ('C4','C'),
	 ('C4','C'),
	 ('C5',''),
	 ('A7',''),
	 ('A2',''),
	 ('b2','B');
INSERT INTO edu.books_event_info (goods_id,event_id) VALUES
	 ('b3',''),
	 ('C1','C'),
	 ('C2',''),
	 ('C3',''),
	 ('A5','');
