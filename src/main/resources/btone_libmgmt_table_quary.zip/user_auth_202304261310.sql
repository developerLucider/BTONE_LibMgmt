INSERT INTO edu.user_auth (user_no,user_auth) VALUES
	 ('1','admin'),
	 ('10','admin'),
	 ('11','admin'),
	 ('12','user'),
	 ('13','admin'),
	 ('14','admin'),
	 ('15','admin'),
	 ('16','user'),
	 ('17','admin'),
	 ('18','user');
INSERT INTO edu.user_auth (user_no,user_auth) VALUES
	 ('19','user'),
	 ('2','admin'),
	 ('20','user'),
	 ('21','user'),
	 ('22','user'),
	 ('23','user'),
	 ('24','user'),
	 ('25','user'),
	 ('26','user'),
	 ('27','user');
INSERT INTO edu.user_auth (user_no,user_auth) VALUES
	 ('28','user'),
	 ('29','user'),
	 ('3','admin'),
	 ('30','user'),
	 ('31','user'),
	 ('32','user'),
	 ('33','user'),
	 ('34','user'),
	 ('35','user'),
	 ('36','admin');
INSERT INTO edu.user_auth (user_no,user_auth) VALUES
	 ('37','user'),
	 ('38','admin'),
	 ('39','admin'),
	 ('4','admin'),
	 ('40','admin'),
	 ('41','admin'),
	 ('5','admin'),
	 ('6','user'),
	 ('7','user'),
	 ('8','user');
INSERT INTO edu.user_auth (user_no,user_auth) VALUES
	 ('9','user');
