INSERT INTO edu.tb_member (SEQ,user_id) VALUES
	 ('1','k');
